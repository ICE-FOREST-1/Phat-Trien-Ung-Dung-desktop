ỨNG DỤNG QUẢN LÝ TIỆM THUỐC (C# WinForms - .NET 8)
====================================================

1. YÊU CẦU
   - Windows 10/11
   - Visual Studio 2022 (bản 17.13 trở lên để hỗ trợ file .slnx, Community miễn phí
     cũng được), cài kèm workload ".NET desktop development"
   - Hoặc chỉ cần .NET 8 SDK trở lên nếu build bằng dòng lệnh (không bắt buộc VS)

2. CÁCH MỞ VÀ CHẠY
   Cách 1 - Dùng Visual Studio:
     - Mở file QuanLyTiemThuoc.slnx bằng Visual Studio (File > Open > Project/Solution)
     - Nhấn F5 hoặc Ctrl+F5 để chạy

   Cách 2 - Dùng dòng lệnh (nếu đã cài .NET SDK):
     cd QuanLyTiemThuoc
     dotnet run

3. CẤU TRÚC THƯ MỤC
   QuanLyTiemThuoc/
   ├── Program.cs                  -> Điểm khởi chạy ứng dụng
   ├── Models/
   │   ├── Customer.cs             -> Model khách hàng
   │   └── Transaction.cs          -> Model giao dịch
   ├── Services/
   │   ├── FileDataManager.cs      -> Đọc/ghi file txt dùng chung
   │   ├── CustomerService.cs      -> Nghiệp vụ CRUD khách hàng
   │   └── TransactionService.cs   -> Nghiệp vụ giao dịch + tính điểm
   ├── Forms/
   │   ├── MainForm.cs             -> Màn hình chính (danh sách khách hàng)
   │   ├── CustomerForm.cs         -> Form thêm/sửa khách hàng
   │   └── TransactionForm.cs      -> Form thêm giao dịch / xem lịch sử
   ├── Data/
   │   ├── customers.txt           -> Dữ liệu khách hàng (tự sinh khi chạy)
   │   └── transactions.txt        -> Dữ liệu giao dịch (tự sinh khi chạy)
   └── KIEM_TRA_LOI.txt            -> Ghi chú các bước kiểm tra lỗi logic đã thực hiện

4. CHỨC NĂNG
   - Thêm / Sửa / Xóa khách hàng
   - Tìm kiếm khách hàng theo tên hoặc số điện thoại
   - Thêm giao dịch mua hàng cho khách hàng, tự động cộng điểm tích lũy
     (quy tắc: 10.000 VNĐ = 1 điểm, có thể chỉnh trong TransactionService.cs
     ở hằng số VND_PER_POINT)
   - Xem lịch sử toàn bộ giao dịch của từng khách hàng
   - Khách hàng mới luôn có Điểm tích lũy = 0 và Ngày đăng ký = thời điểm tạo tài khoản
   - Toàn bộ dữ liệu lưu vào 2 file .txt trong thư mục Data (định dạng phân tách bằng "|"),
     tự động đọc lại khi mở ứng dụng lần sau

5. GHI CHÚ
   - Vì môi trường tạo mã nguồn này không có Windows/.NET SDK để build & chạy WinForms
     trực tiếp, mã nguồn đã được rà soát logic thủ công kỹ lưỡng (xem KIEM_TRA_LOI.txt).
     Bạn hãy Build thử 1 lần trong Visual Studio trước khi dùng để chắc chắn máy bạn
     không phát sinh lỗi biên dịch đặc thù.
